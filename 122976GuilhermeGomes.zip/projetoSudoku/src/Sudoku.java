class Sudoku {
	private SudokuBoard sudokuBoard;
	public ColorImage boardImage; // para ver no PandionJ
	
	public Sudoku(String file, int difficulty) {
        int[][] newGame = SudokuAux.readFiles(file);
        sudokuBoard = new SudokuBoard(newGame, difficulty);
        sudokuBoard.alteredBoard = SudokuAux.dificuldade(sudokuBoard.alteredBoard, difficulty);
        boardImage = SudokuAux.drawNumbers(SudokuAux.generateGrid(), sudokuBoard.alteredBoard);
	}
	
	public void play(int line, int column, int num) {
		SudokuAux.changePosition(line, column, num);
	}
	
	public void undo() {
	sudokuBoard.undo();
	}
	
	public void reset() {
		sudokuBoard.resetSudoku();
	}
	
}
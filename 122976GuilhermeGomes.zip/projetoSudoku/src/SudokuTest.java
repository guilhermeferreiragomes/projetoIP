public class SudokuTest {
	public static void main() {
		Sudoku sudoku = new Sudoku("jogo1.sud", 50);
		return;
		}
}
class SudokuBoard {
	ColorImage sudoku = SudokuAux.generateGrid();
	int[][] initialBoard = new int[9][9];
	int[][] alteredBoard = new int[9][9];
	int[][] save = new int[81][2];
	int count; 
	int dificuldade;

	
	SudokuBoard(int[][] board, int dificuldade) {
		this.initialBoard = SudokuAux.dificuldade(board, dificuldade);
		for (int x = 0; x < initialBoard.length; x++) {
		for (int y = 0; y < initialBoard[x].length; y++) {
				initialBoard[x][y] = alteredBoard[x][y];
			}
		}
		return;
	}

	int getNumber(int row, int column) {
		return alteredBoard[row][column];
	}

	void putNumber(int row, int column, int n) {
		if (getNumber(row,column) == 0) 
			alteredBoard[row][column] = n;
		else 
			throw new IllegalArgumentException("A posi��o escolhida j� tem um n�mero atribu�do.");
		save[count][0] = row;
		save[count][1] = column;
		return;
	}

	void makeMove() {
		int x = (int) Math.random() * 10;
		int y = (int) Math.random() * 10;
		if (getNumber(x, y) == 0) {
			putNumber(x, y, (int) Math.random() * 10);
		}
		if (!SudokuAux.matrizValidaBloco(alteredBoard, x, y)) {
			throw new IllegalArgumentException("Cuidado! O Sudoku vai se tornar inv�lido.");
		}
		return;
	}

	void resetSudoku() {
		for (int x = 0; x < initialBoard.length; x++) {
			for (int y = 0; y < initialBoard[x].length; y++) {
				alteredBoard[x][y] = initialBoard[x][y];
			}
		}
		return;
	}
	
	/*
	void validSegment() {
		int[][] v = new int[3][3];
		for (int x = 0; x < v.length; x++) {
			for(int y = 0; y < v.length; y++) {
				if(SudokuAux.matrizValidaBloco(alteredBoard, x, y))
					v[x][y] = x;
			}
		}
		return;
	}
	*/
		

	void validRow() {
		int[] v = new int[9];
		for (int x = 0; x < v.length; x++) {
				if (SudokuAux.matrizValidaLinha(alteredBoard, x))
					v[x] = x;
			}
		return;
	}
	
	void validColumn() {
		int[] v = new int[9];
		for(int y = 0; y < v.length; y++) {
				if(SudokuAux.matrizValidaColuna(alteredBoard, y))
					v[y] = y;
			}
		return;
	}
	
	boolean validSudoku() {
		for(int x = 0; x < alteredBoard.length; x++) {
			for(int y = 0; y < alteredBoard.length; y++) {
				if(alteredBoard[x][y] == 0)
					throw new IllegalArgumentException("O Sudoku ainda n�o est� completo :(");
				if(!SudokuAux.sudokuValido(alteredBoard))
					throw new IllegalArgumentException("O Sudoku n�o � valido :(");
			}
		}
		return true;
	}
	
	void undo() {
		count --;
		alteredBoard[save[count][0]][save[count][1]] = 0;
	}
	
	
	public int[][] matriz() {
		return alteredBoard;
	}
}

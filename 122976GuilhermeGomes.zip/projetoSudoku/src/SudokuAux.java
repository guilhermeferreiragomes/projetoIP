import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class SudokuAux {
	static final int BoardSize = 9;
	static final int imageSize = Param.SQUARE_SIZE * 9;
	static final ColorImage board = new ColorImage(imageSize, imageSize, Param.SQUARE_BACKCOLOR);
	public static int[][] matriz = new int[BoardSize][BoardSize];
	public static int[][] matriz2 = { { 1, 2, 3, 4, 5, 6, 7, 8, 9 }, { 4, 5, 6, 7, 8, 9, 1, 2, 3 },
			{ 7, 8, 9, 1, 2, 3, 4, 5, 6 }, { 2, 1, 4, 3, 6, 5, 8, 9, 7 }, { 3, 6, 5, 8, 9, 7, 2, 1, 4 },
			{ 8, 9, 7, 2, 1, 4, 3, 6, 5 }, { 5, 3, 1, 6, 4, 2, 9, 7, 8 }, { 6, 4, 2, 9, 7, 8, 5, 3, 1 },
			{ 9, 7, 8, 5, 3, 1, 6, 4, 2 } };

	static boolean sudokuValido(int board[][]) {
		for (int i = 0; i < BoardSize; i++) {
			if (!matrizValidaLinha(board, i) || !matrizValidaColuna(board, i)) {
				throw new IllegalArgumentException("O Sudoku n�o � valido :(");

			}
			for (int x = 0; x < BoardSize; x = x + 3) {
				for (int y = 0; y < BoardSize; y = y + 3) {
					if (!matrizValidaBloco(board, x, y))
						throw new IllegalArgumentException("O Sudoku n�o � valido :(");
				}
			}
		}
		return true;
	}

	static boolean matrizValidaLinha(int[][] board, int line) {
		boolean[] v = new boolean[BoardSize];
		for (int x = 0; x < BoardSize; x++) {
			int n = board[line][x];
			if (n != 0)
				if (v[n - 1])
					return false;
				else
					v[n - 1] = true;
		}
		return true;
	}

	static boolean matrizValidaColuna(int[][] board, int column) {
		boolean[] v = new boolean[BoardSize];
		for (int y = 0; y < BoardSize; y++) {
			int n = board[y][column];
			if (n != 0)
				if (v[n - 1])
					return false;
				else
					v[n - 1] = true;
		}
		return true;
	}

	static boolean matrizValidaBloco(int[][] board, int row, int column) {
		boolean[] v = new boolean[BoardSize];
		int segmentLine = row - (row % 3);
		int segmentColumn = column - (column % 3);
		for (int x = segmentLine; x != segmentLine + 3; x++) {
			for (int y = segmentColumn; y != segmentColumn + 3; y++) {
				int n = board[x][y];
				if (n != 0)
					if (v[n - 1])
						return false;
					else
						v[n - 1] = true;
			}
		}
		return true;
	}

	static int[][] dificuldade(int[][] m, int percentage) {
		for (int x = 0; x < matriz.length; x++) {
			for (int y = 0; y < matriz[x].length; y++) {
				if (Math.random() * 100 < percentage)
					m[x][y] = 0;
			}
		}
		return m;
	}

	static ColorImage generateGrid() {
		for (int x = 0; x < imageSize; x++) {
			for (int y = 0; y < imageSize; y++) {

				// Moldura Sudoku
				board.setColor(x, 0, Param.SEGMENT_GRID_COLOR);
				board.setColor(x, 1, Param.SEGMENT_GRID_COLOR);
				board.setColor(x, imageSize - 1, Param.SEGMENT_GRID_COLOR);
				board.setColor(x, imageSize - 2, Param.SEGMENT_GRID_COLOR);
				board.setColor(0, y, Param.SEGMENT_GRID_COLOR);
				board.setColor(1, y, Param.SEGMENT_GRID_COLOR);
				board.setColor(imageSize - 1, y, Param.SEGMENT_GRID_COLOR);
				board.setColor(imageSize - 2, y, Param.SEGMENT_GRID_COLOR);

				// Linhas divis�rias
				if (x % Param.SQUARE_SIZE == 0 || y % Param.SQUARE_SIZE == 0)
					board.setColor(x, y, Param.GRID_COLOR);

				// Linhas verticais mais espessas
				if (x == Param.SQUARE_SIZE * 3 || x == Param.SQUARE_SIZE * 6)
					board.setColor(x, y, Param.SEGMENT_GRID_COLOR);
				if (x == Param.SQUARE_SIZE * 3 - 1 || x == Param.SQUARE_SIZE * 6 - 1)
					board.setColor(x, y, Param.SEGMENT_GRID_COLOR);

				// Linhas horizontais mais espessas
				if (y == Param.SQUARE_SIZE * 3 || y == Param.SQUARE_SIZE * 6)
					board.setColor(x, y, Param.SEGMENT_GRID_COLOR);
				if (y == Param.SQUARE_SIZE * 3 - 1 || y == Param.SQUARE_SIZE * 6 - 1)
					board.setColor(x, y, Param.SEGMENT_GRID_COLOR);
			}
		}
		drawNumbers(board, matriz); 
		return board;
	}

	static ColorImage drawNumbers(ColorImage board, int[][] matriz) {
		int a = Param.SQUARE_SIZE / 2;
		int b = a;
		for (int x = 0; x != 9; x++) {
			for (int y = 0; y != 9; y++) {
				if (matriz[x][y] == 0)
					board.drawCenteredText(a, b, " ", Param.LETTER_SIZE, Param.TEXTCOLOR);
				else
					board.drawCenteredText(a, b, String.valueOf(matriz[x][y]), Param.LETTER_SIZE, Param.TEXTCOLOR);
				a += Param.SQUARE_SIZE;
			}
			a = Param.SQUARE_SIZE / 2;
			b += Param.SQUARE_SIZE;
		}
		return board;
	}


	static void drawWhiteSquare(int x, int y) {
		for (int i = x * Param.SQUARE_SIZE; i < x * Param.SQUARE_SIZE + Param.SQUARE_SIZE - 3; i++) {
			for (int j = y * Param.SQUARE_SIZE; j < y * Param.SQUARE_SIZE + Param.SQUARE_SIZE - 3; j++) {
				board.setColor(i + 2, j + 2, Param.SQUARE_BACKCOLOR);
				// i + 2, j + 2 para o quadrado ficar centrado na c�lula
			}
		}
		return;
	}

	static void changePosition(int x, int y, int n) {
		if (x >= 0 && x < imageSize && y >= 0 && y < imageSize) {
			matriz[x][y] = n;
			drawWhiteSquare(x, y);
			drawNumbers(board,matriz);
		}
		return;
	}

	static void invalidRow() {
		for (int x = 0; x < BoardSize; x++) {
			if (!matrizValidaLinha(matriz, x)) { // Quando � igual a false (linha inv�lida)
				drawHorizontalLine(x * Param.SQUARE_SIZE, 0, board.getWidth() - 1, Param.OUTLINE_COLOR);
				drawHorizontalLine(x * Param.SQUARE_SIZE + Param.SQUARE_SIZE - 1, 0, board.getWidth() - 1,
						Param.OUTLINE_COLOR);
			}
		}
		return;
	}

	static void drawHorizontalLine(int row, int startX, int endX, Color color) {
		for (int x = startX; x <= endX; x++) {
			board.setColor(x, row, color);
		}
	}

	static void invalidColumn() {
		for (int y = 0; y < BoardSize; y++) {
			if (!matrizValidaColuna(matriz, y)) { // Quando � igual a false (coluna inv�lida)
				drawVerticalLine(y * Param.SQUARE_SIZE, 0, board.getHeight() - 1, Param.OUTLINE_COLOR);
				drawVerticalLine(y * Param.SQUARE_SIZE + Param.SQUARE_SIZE - 1, 0, board.getHeight() - 1,
						Param.OUTLINE_COLOR);
			}
		}
		return;
	}

	static void drawVerticalLine(int column, int startY, int endY, Color color) {
		for (int y = startY; y <= endY; y++) {
			board.setColor(column, y, color);
		}
	}

	// read files
	public static int[][] readFiles(String file) {
		int[][] matrizFile = new int[9][9];
		try {
			Scanner boardSc = new Scanner(new File(file));
			while(boardSc.hasNextLine()) {
				for(int x = 0; x < matrizFile.length; x++) {
					String line = boardSc.nextLine();
					String[] breakLine = line.split(" ");
					for(int y = 0; y < matriz[x].length; y++) {
						int s = Integer.parseInt(breakLine[y]);
						matriz[x][y] = s;
				}
			}
		}
			boardSc.close();
		} catch (FileNotFoundException a) {
			System.err.println("File error: " + file);
		}
		return matrizFile;	
	}

//	public static int[][] readFiles(String ficheiro) {
//		try {
//			File sudokufile = new File(ficheiro);
//			System.out.println("aqui");
//
//			Scanner scanner = new Scanner(sudokufile);
//			System.out.println("aqui1");
//
//			scanner.hasNextLine();
//			System.out.println("aqui2");
//
//			int n = 0;
//			for (int x = 0; x < 9; x++) {
//				for (int y = 0; y < 9; y++) {
//					n = scanner.nextInt();
//					System.out.println("aqui3");
//
//					matriz[x][y] = n;
//				}
//			}
//			scanner.close();
//		} catch (FileNotFoundException e) {
//			System.err.println("File Not Found");
//		}
//		return matriz;
//	}

	static void teste() {
		dificuldade(matriz,0);
		generateGrid();
		drawNumbers(board,matriz);
		changePosition(0,0,2);
		invalidRow();
		invalidColumn();
		return;
	}

	
}
